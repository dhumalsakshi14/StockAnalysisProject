package com.example.my_pro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyProApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyProApplication.class, args);
	}

}
