package com.example.my_pro.utills;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileCreator {
    public static void main(String[] args) {
        try {
            // Define the file path
            File file = new File("C:\\Users\\Dhumal Sakshi\\Desktop\\MY_PRO\\my_pro\\data.jxx");

            // Create the file
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getAbsolutePath());
            } else {
                System.out.println("File already exists.");
            }

            // Write content to the file
            FileWriter writer = new FileWriter(file);
            writer.write("This is a sample .jxx file content.");
            writer.close();

            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
