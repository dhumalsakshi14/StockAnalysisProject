package com.example.my_pro.model;
public class StockData {

}
