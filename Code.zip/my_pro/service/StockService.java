package com.example.my_pro.service;

import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.Map;

public interface StockService {
    Map<String, Object> processStockData(MultipartFile file, String format) throws IOException, InterruptedException;
}
