package com.example.my_pro.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

@Service
public class StockServiceImpl implements StockService {

    private static final String PYTHON_SCRIPT_PATH = "C:\\Users\\Dhumal Sakshi\\Desktop\\MY_PRO\\my_pro\\StockAnalysis.py";

    @Override
    public Map<String, Object> processStockData(MultipartFile file, String format) throws IOException, InterruptedException {
        File tempFile = File.createTempFile("uploaded_stock_data", ".csv");
        file.transferTo(tempFile.toPath());


        ProcessBuilder processBuilder = new ProcessBuilder("python", PYTHON_SCRIPT_PATH, tempFile.getAbsolutePath(), format);
        processBuilder.redirectErrorStream(true);
        Process process = processBuilder.start();

        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }

        int exitCode = process.waitFor();
        tempFile.delete();

        if (exitCode == 0) {
            return parsePythonResponse(response.toString());
        } else {
            throw new IOException("Python script execution failed.");
        }
    }

    private Map<String, Object> parsePythonResponse(String response) {
        Map<String, Object> result = new HashMap<>();
        try {
            result = new com.fasterxml.jackson.databind.ObjectMapper().readValue(response, Map.class);
        } catch (Exception e) {
            result.put("error", "Failed to parse Python script response.");
        }
        return result;
    }
}
