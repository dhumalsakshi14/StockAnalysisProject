package com.example.my_pro.exception;

public class PythonScriptException extends RuntimeException {
    public PythonScriptException(String message) {
        super(message);
    }
}
